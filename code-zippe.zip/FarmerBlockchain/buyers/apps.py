from django.apps import AppConfig


class BuyersConfig(AppConfig):
    name = 'buyers'
